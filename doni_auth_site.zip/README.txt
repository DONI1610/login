Doni Auth + Notes Web

Upload these files to the root of your GitHub Pages repo and enable Pages (branch main, root).
Make sure in Firebase Console you enabled Authentication (Email/Password) and created Firestore.
The firebaseConfig included is the one you provided.
